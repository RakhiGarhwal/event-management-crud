package com.example.event_management;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
public class EventController {

    List<Event> events = new ArrayList<>();
    int idCounter = 1;

    @PostMapping("/events")
    public Event addEvent(@RequestBody Event event) {
        event.setId(idCounter++);
        events.add(event);
        return event;
    }

    @GetMapping("/events")
    public List<Event> getEvents() {
        return events;
    }

    @PutMapping("/events/{id}")
    public Event updateEvent(@PathVariable int id,
                             @RequestBody Event updatedEvent) {

        for (Event e : events) {
            if (e.getId() == id) {
                e.setName(updatedEvent.getName());
                e.setDate(updatedEvent.getDate());
                return e;
            }
        }
        return null;
    }

    @DeleteMapping("/events/{id}")
    public String deleteEvent(@PathVariable int id) {
        events.removeIf(e -> e.getId() == id);
        return "Event deleted";
    }
}
